# 84000/data-translation-memory

84000 Translation Memory files
